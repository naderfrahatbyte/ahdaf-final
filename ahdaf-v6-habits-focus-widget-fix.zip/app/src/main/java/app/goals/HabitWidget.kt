package app.goals

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HabitWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            PREV, NEXT -> {
                val prefs = context.getSharedPreferences("habit_widget", 0)
                val habits = selected(context)
                if (habits.isNotEmpty()) {
                    val i = prefs.getInt("index", 0)
                    val next = if (intent.action == NEXT) (i + 1) % habits.size else (i - 1 + habits.size) % habits.size
                    prefs.edit().putInt("index", next).apply()
                }
                refresh(context)
            }
            TOGGLE -> {
                val id = intent.getStringExtra(EXTRA_HABIT_ID).orEmpty()
                if (id.isNotBlank()) toggleHabit(context, id)
                refresh(context)
            }
        }
    }

    companion object {
        const val PREV = "app.goals.HABIT_WIDGET_PREV"
        const val NEXT = "app.goals.HABIT_WIDGET_NEXT"
        const val TOGGLE = "app.goals.HABIT_WIDGET_TOGGLE"
        const val EXTRA_HABIT_ID = "habit_id"

        private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, HabitWidget::class.java))
            ids.forEach { update(context, manager, it) }
        }

        private fun selected(context: Context): List<JSONObject> {
            val raw = context.getSharedPreferences("g", 0).getString("d", "") ?: ""
            return try {
                val habits = JSONObject(raw).optJSONArray("habits") ?: return emptyList()
                (0 until habits.length()).mapNotNull { i ->
                    val h = habits.optJSONObject(i) ?: return@mapNotNull null
                    if (h.optBoolean("widget", false)) h else null
                }
            } catch (_: Exception) { emptyList() }
        }

        private fun toggleHabit(context: Context, id: String) {
            val prefs = context.getSharedPreferences("g", 0)
            val raw = prefs.getString("d", "") ?: return
            try {
                val root = JSONObject(raw)
                val habits = root.optJSONArray("habits") ?: return
                val habit = (0 until habits.length()).mapNotNull { habits.optJSONObject(it) }
                    .firstOrNull { it.optString("id") == id } ?: return
                val dates = habit.optJSONArray("doneDates") ?: JSONArray().also { habit.put("doneDates", it) }
                val date = today()
                var found = -1
                for (i in 0 until dates.length()) if (dates.optString(i) == date) { found = i; break }
                val completed = found < 0
                if (completed) dates.put(date) else {
                    val replacement = JSONArray()
                    for (i in 0 until dates.length()) if (i != found) replacement.put(dates.get(i))
                    habit.put("doneDates", replacement)
                }
                prefs.edit().putString("d", root.toString()).apply()

                val reward = habit.optDouble("focusReward", 0.0).coerceAtLeast(0.0)
                if (reward > 0.0) {
                    FocusStore.init(context)
                    FocusStore.add(if (completed) reward else -reward,
                        (if (completed) "مكافأة العادة: " else "تراجع عن إنجاز العادة: ") + habit.optString("title"),
                        "habit|$id|$date|${if (completed) "done" else "undo"}", false)
                    FocusStore.save(true)
                }
                MainActivity.notifyHabitWidgetChanged()
            } catch (_: Exception) { }
        }

        private fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_habit)
            val habits = selected(context)
            val prefs = context.getSharedPreferences("habit_widget", 0)
            val idx = if (habits.isEmpty()) 0 else prefs.getInt("index", 0).coerceIn(0, habits.lastIndex)
            val habit = habits.getOrNull(idx)
            val done = habit?.optJSONArray("doneDates")?.let { dates -> (0 until dates.length()).any { dates.optString(it) == today() } } == true
            views.setTextViewText(R.id.habit_title, when {
                habit == null -> "اختر عادة من قسم العادات"
                done -> "✓  ${habit.optString("title")}"
                else -> habit.optString("title")
            })
            views.setTextViewText(R.id.habit_count, if (habits.isEmpty()) "—" else "${idx + 1}/${habits.size}")
            views.setTextViewText(R.id.habit_title, when {
                habit == null -> "اختر عادة من قسم العادات"
                done -> "✓ ${habit.optString("title")}"
                else -> habit.optString("title")
            })
            fun pending(action: String, request: Int, habitId: String? = null): PendingIntent {
                val intent = Intent(context, HabitWidget::class.java).setAction(action)
                if (habitId != null) intent.putExtra(EXTRA_HABIT_ID, habitId)
                return PendingIntent.getBroadcast(context, request, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            }
            views.setOnClickPendingIntent(R.id.habit_prev, pending(PREV, 7101))
            views.setOnClickPendingIntent(R.id.habit_next, pending(NEXT, 7102))
            if (habit != null) views.setOnClickPendingIntent(R.id.habit_title, pending(TOGGLE, 7200 + idx, habit.optString("id")))
            manager.updateAppWidget(id, views)
        }
    }
}

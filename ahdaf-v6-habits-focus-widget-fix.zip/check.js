
const $=s=>document.querySelector(s);
const PAL=[getComputedStyle(document.documentElement).getPropertyValue('--g').trim()||'#d4a95a','#e07a6a','#5bb8a8','#a98bd8','#7fa8e8','#9cc27a'];
const DN=['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];
const MON=[...Array(12)].map((_,i)=>new Date(2026,i,1).toLocaleDateString('ar-EG-u-nu-latn',{month:'long'}));
const KEY='ahdaf-v3';
let S={goals:[],loose:[],lists:[],habits:[]},tab='tasks',backlog=false,pend=null,lpf=false,D=null,listShowArchived=false;
const pad=n=>String(n).padStart(2,'0');
const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const parse=s=>{const[y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d,12)};
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
const diff=(a,b)=>Math.round((parse(b)-parse(a))/864e5);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Math.random().toString(36).slice(2,9);
const ic=n=>`<svg class="i"><use href="#i-${n}"/></svg>`;
let sel=iso(new Date()),cy=new Date().getFullYear(),cm=new Date().getMonth();
const hasA=()=>typeof Android!=='undefined';
const pref=k=>{try{return hasA()?Android.getPref(k)!==0:localStorage.getItem('p_'+k)!=='0'}catch(e){return true}};
const setPref=(k,v)=>{try{if(hasA())Android.setPref(k,v?1:0);else localStorage.setItem('p_'+k,v?'1':'0')}catch(e){}};
function load(){let raw='';try{raw=(hasA()?Android.load():localStorage.getItem(KEY))||''}catch(e){}try{const s=JSON.parse(raw||'null');if(Array.isArray(s))S.goals=s;else if(s){S.goals=s.goals||[];S.loose=s.loose||[];S.lists=s.lists||[];S.habits=s.habits||[]}}catch(e){}}
function persist(){const j=JSON.stringify(S);try{if(hasA())Android.save(j);else localStorage.setItem(KEY,j)}catch(e){}}
const kids=g=>S.goals.filter(x=>x.parent===g.id);
const tasksOf=g=>g.long?kids(g).flatMap(k=>k.tasks):g.tasks;
const prog=g=>{const t=tasksOf(g);return t.length?t.filter(x=>x.done).length/t.length:0};
const gcol=g=>{const p=g.parent&&S.goals.find(x=>x.id===g.parent);return(p?p.color:g.color)||PAL[0]};
const shade=(c,i)=>i%3===0?`color-mix(in srgb,${c} 62%,#fff)`:i%3===1?c:`color-mix(in srgb,${c} 70%,#000)`;
function ovd(){const t=iso(new Date()),a=[];S.goals.forEach(g=>g.tasks.forEach(k=>{if(k.date<t&&!k.done)a.push({k,g})}));S.loose.forEach(k=>{if(k.date<t&&!k.done)a.push({k})});return a.sort((x,y)=>x.k.date<y.k.date?-1:1)}
function weekNo(ws){const y=addDays(ws,3).getFullYear(),j=new Date(y,0,1,12);let f=addDays(j,-((j.getDay()+1)%7));if(addDays(f,3).getFullYear()!==y)f=addDays(f,7);return Math.round((ws-f)/6048e5)+1}

/* ---------- الاحتفال ---------- */
let AC;const ac=()=>{if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}}return AC};
function note(f,t0,dur,vol){const a=ac();if(!a)return;const o=a.createOscillator(),g=a.createGain(),t=a.currentTime+t0;o.type='sine';o.frequency.value=f;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol,t+.01);g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+dur+.05)}
function chime(l){if(l===1){note(1318.5,0,.4,.22);note(1760,.09,.5,.22)}else{[523.25,659.25,783.99,1046.5,1318.5].forEach((f,i)=>note(f,i*.1,.8,.2));[1046.5,1318.5,1568,2093].forEach(f=>note(f,.62,1.6,.12))}}
const fx=$('#fx'),cx=fx.getContext('2d');let raf=0;
function celebrate(l){
  if(pref('snd'))chime(l);
  try{if(navigator.vibrate)navigator.vibrate(l===2?[30,70,30,70,80]:25)}catch(e){}
  if(!pref('anim'))return;
  const dpr=window.devicePixelRatio||1;fx.width=innerWidth*dpr;fx.height=innerHeight*dpr;
  const W=fx.width,H=fx.height,t0=performance.now(),dur=l===2?2600:1000,n=l===2?120:18;
  const ps=[...Array(n)].map((_,i)=>({a:Math.random()*Math.PI*2,x:Math.random(),v:.5+Math.random()*.9,s:.6+Math.random()*.8,c:PAL[i%PAL.length],r:Math.random()*360}));
  cancelAnimationFrame(raf);
  const step=now=>{
    const t=Math.min(1,(now-t0)/dur),X=W/2,Y=H*.55,fade=1-t;cx.clearRect(0,0,W,H);
    if(l===1){cx.globalAlpha=fade;cx.strokeStyle=PAL[0];cx.lineWidth=3*dpr;cx.beginPath();cx.arc(X,Y,(30+t*110)*dpr,0,7);cx.stroke();
      ps.forEach(p=>{const r=(24+t*130*p.s)*dpr;cx.fillStyle=p.c;cx.beginPath();cx.arc(X+Math.cos(p.a)*r,Y+Math.sin(p.a)*r,4.5*dpr*p.s*(1-t*.6),0,7);cx.fill()})}
    else{const pu=Math.sin(Math.PI*t),gr=(120+220*t)*dpr,g=cx.createRadialGradient(X,Y,0,X,Y,gr);g.addColorStop(0,'rgba(246,214,140,'+(.6*pu)+')');g.addColorStop(1,'rgba(246,214,140,0)');
      cx.globalAlpha=1;cx.fillStyle=g;cx.fillRect(0,0,W,H);cx.globalAlpha=fade;cx.lineWidth=3*dpr;cx.lineCap='round';
      for(let k=0;k<12;k++){const a=k*Math.PI/6,r0=(40+t*80)*dpr,r1=r0+(30+60*pu)*dpr;cx.strokeStyle=PAL[k%PAL.length];cx.beginPath();cx.moveTo(X+Math.cos(a)*r0,Y+Math.sin(a)*r0);cx.lineTo(X+Math.cos(a)*r1,Y+Math.sin(a)*r1);cx.stroke()}
      ps.forEach((p,i)=>{const x=p.x*W+Math.sin(t*6+i)*20*dpr,y=-30*dpr+t*H*p.v*1.1;cx.globalAlpha=t>.75?(1-t)*4:1;cx.fillStyle=p.c;cx.save();cx.translate(x,y);cx.rotate((p.r+t*540)*Math.PI/180);cx.fillRect(-4*dpr*p.s,-7*dpr*p.s,8*dpr*p.s,14*dpr*p.s);cx.restore()})}
    cx.globalAlpha=1;if(t<1)raf=requestAnimationFrame(step);else cx.clearRect(0,0,W,H)};
  raf=requestAnimationFrame(step);
}
function tog(type,a,b){
  let t,g0,p0=0,par0,pp0=0;
  if(type==='g'){g0=S.goals.find(x=>x.id===a);t=g0&&g0.tasks.find(x=>x.id===b);if(g0){p0=prog(g0);par0=S.goals.find(x=>x.id===g0.parent);pp0=par0?prog(par0):0}}
  else if(type==='l')t=S.loose.find(x=>x.id===a);
  else{const L=S.lists.find(x=>x.id===a);t=L&&L.items.find(x=>x.id===b)}
  if(!t)return;t.done=!t.done;let rw=0;
  if(t.done&&type!=='i'){
    if(t.rw>0&&!t.rd){rw=focusReward(t.rw,t.title,type+'|'+a+(b?'|'+b:''));if(rw>0)t.rd=1}
    if(t.rep)spawnNext(type,g0,t);
  }
  persist();
  if(t.done){let lv=1;if(g0){if(prog(g0)>=.999&&p0<.999)lv=2;if(par0&&prog(par0)>=.999&&pp0<.999)lv=2}celebrate(lv);if(rw>0)rewardFx(rw)}
  render();
}


/* ---------- مكافأة Focus والتكرار والتراجع والبحث ---------- */
const focusReward=(amt,title,ref)=>{try{return hasA()&&Android.focusReward?+Android.focusReward(amt,title,ref)||0:0}catch(e){return 0}};
function rewardFx(n){const d=document.createElement('div');d.className='rwd';d.textContent='+'+Number((+n).toFixed(1));document.body.appendChild(d);setTimeout(()=>d.remove(),1700)}
function spawnNext(type,g,t){
  const step=t.rep==='w'?7:1,today=iso(new Date());let n=addDays(parse(t.date),step);while(iso(n)<=today)n=addDays(n,step);
  const ds=iso(n),arr=type==='g'?(g&&g.tasks):S.loose;if(!arr)return;
  if(type==='g'&&ds>g.end)return;
  if(arr.some(x=>x.title===t.title&&x.date===ds))return;
  const o={id:uid(),title:t.title,desc:t.desc||'',date:ds,done:false,rep:t.rep};if(t.pr)o.pr=1;if(t.rw>0)o.rw=t.rw;arr.push(o)
}
let UNDO=null,utm=0;
function toast(msg,undo){const t=$('#toast');t.innerHTML=`<span>${esc(msg)}</span>${undo?'<button data-un="1">تراجع</button>':''}`;t.classList.add('on');clearTimeout(utm);utm=setTimeout(()=>{t.classList.remove('on');UNDO=null},6500)}
function doUndo(){if(!UNDO)return;UNDO();UNDO=null;persist();$('#toast').classList.remove('on');render()}
function postpone(m){
  if(m==='d'){const i=$('#f-dt');if(i){i.focus();try{i.showPicker()}catch(e){}}return}
  syncTask();const nd=iso(addDays(new Date(),+m)),p=D.key.split('|');
  const g=p[0]==='g'?S.goals.find(x=>x.id===p[1]):null,o=g?g.tasks.find(x=>x.id===p[2]):S.loose.find(x=>x.id===p[1]);
  if(!o)return;
  if(g&&(nd<g.start||nd>g.end))return drawTask('اليوم خارج مدى الهدف');
  o.date=nd;persist();closeS();render();toast('تم التأجيل إلى '+nd)
}
const norm=s=>String(s||'').toLowerCase().replace(/[\u064b-\u065f\u0670\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه');
function sheetSearch(){D={kind:'search'};show(`<input class="big" id="q-t" placeholder="ابحث عن مهمة أو هدف" autocomplete="off"><div id="q-r" style="margin-top:10px"></div>`);setTimeout(()=>{const i=$('#q-t');if(i)i.focus()},80)}
function drawSearch(v){
  const q=norm(v.trim()),r=$('#q-r');if(!r)return;if(!q){r.innerHTML='';return}
  const hit=x=>norm(x).includes(q),gs=[],ts=[];
  S.goals.forEach(g=>{if(hit(g.title))gs.push(g);g.tasks.forEach(t=>{if(hit(t.title)||hit(t.desc))ts.push({t,g,k:'g|'+g.id+'|'+t.id})})});
  S.loose.forEach(t=>{if(hit(t.title)||hit(t.desc))ts.push({t,k:'l|'+t.id})});
  ts.sort((a,b)=>(a.t.done-b.t.done)||(a.t.date<b.t.date?-1:a.t.date>b.t.date?1:0));
  const h=gs.map(g=>`<div class="mtk" data-g="${g.id}"><b>${esc(g.title)}</b><small>هدف${g.long?' طويل المدى':''}</small></div>`).join('')+ts.slice(0,40).map(x=>`<div class="mtk" data-ed="${x.k}"><b>${x.t.done?'✓ ':''}${esc(x.t.title)}</b><small>${x.t.date}${x.g?' · '+esc(x.g.title):''}</small></div>`).join('');
  r.innerHTML=h||'<div class="hint">لا نتائج</div>'
}
let skipN=0;
function startList(){
  const t=iso(new Date()),lim=iso(addDays(new Date(),2)),a=[];
  S.goals.forEach(g=>g.tasks.forEach(k=>{if(!k.done)a.push({k,g,key:'g|'+g.id+'|'+k.id})}));
  S.loose.forEach(k=>{if(!k.done)a.push({k,key:'l|'+k.id})});
  const cmp=(x,y)=>x.k.date<y.k.date?-1:x.k.date>y.k.date?1:0,rank=(x,y)=>((y.k.pr?1:0)-(x.k.pr?1:0))||cmp(x,y);
  return a.filter(x=>x.k.date<=t).sort(rank).concat(a.filter(x=>x.k.date>t&&x.k.date<=lim).sort((x,y)=>cmp(x,y)||rank(x,y)))
}
function startCard(today){
  if(sel!==today)return '';const st=startList();if(!st.length)return '';
  const x=st[skipN%st.length],d=diff(x.k.date,today);
  const why=d>0?`متأخرة ${d} ${d===1?'يوم':'أيام'}`:d===0?'مستحقة اليوم':d===-1?'غدًا':'بعد غد';
  return `<div class="card strt"><h5>ابدأ الآن</h5><div class="tk"><button class="ck" style="--c:${x.g?gcol(x.g):'var(--m)'}" data-tg="${x.key}">${ic('check')}</button><div class="tx" data-ed="${x.key}"><b>${x.k.pr?'★ ':''}${esc(x.k.title)}${x.k.rw>0?`<span class="rwb">+${Number(x.k.rw)}</span>`:''}</b><small>${why}${x.g?' · '+esc(x.g.title):''}</small></div>${st.length>1?`<button class="ib sm" data-sk="1" aria-label="التالية">${ic('l')}</button>`:''}</div></div>`
}

/* ---------- الأسبوع والأهداف ---------- */
function bars(ws){
  const wsS=iso(ws);
  const seg=g=>{const a=diff(wsS,g.start),b=diff(wsS,g.end);return(b<0||a>6)?null:{g,a,b,s:Math.max(a,0),e:Math.min(b,6)}};
  const pack=a=>{const ends=[];a.sort((x,y)=>x.s-y.s||y.e-x.e).forEach(it=>{let r=ends.findIndex(e=>e<it.s);if(r<0){r=ends.length;ends.push(0)}ends[r]=it.e;it.r=r})};
  const top=[];
  S.goals.filter(g=>g.long).forEach(L=>{const ls=seg(L),ks=kids(L).map(seg).filter(Boolean),all=ks.concat(ls||[]);if(all.length)top.push({s:Math.min(...all.map(x=>x.s)),e:Math.max(...all.map(x=>x.e)),L,ks})});
  S.goals.filter(g=>!g.long&&!(g.parent&&S.goals.some(x=>x.id===g.parent))).forEach(g=>{const x=seg(g);if(x)top.push({s:x.s,e:x.e,x})});
  pack(top);
  const bar=(x,c,off)=>{const{g,a,b,s,e}=x,p=prog(g),f=Math.max(0,Math.min(1,(p*(b-a+1)-(s-a))/(e-s+1)));return `<button class="bar" data-g="${g.id}" style="--c:${c};grid-column:${s-off+1}/${e-off+2};grid-row:${x.r+1}"><i style="width:${f*100}%"></i></button>`};
  return top.map(it=>{
    if(it.x)return bar(Object.assign({},it.x,{r:it.r}),gcol(it.x.g),0);
    const{L,ks,s,e}=it,p=prog(L);pack(ks);
    const kb=ks.map(x=>bar(x,shade(L.color,kids(L).indexOf(x.g)),s)).join('');
    return `<div class="grp" data-g="${L.id}" style="grid-column:${s+1}/${e+2};grid-row:${it.r+1};border-color:${L.color};background:color-mix(in srgb,${L.color} ${Math.round(14+70*p)}%,transparent)"><div class="gk" style="grid-template-columns:repeat(${e-s+1},1fr)">${kb}</div></div>`;
  }).join('');
}
function row(x,extra){return `<div class="tk${x.t.done?' done':''}"><button class="ck" style="--c:${x.g?gcol(x.g):'var(--m)'}" data-tg="${x.k}">${ic('check')}</button><div class="tx" data-ed="${x.k}"><b>${x.t.pr?'★ ':''}${esc(x.t.title)}${x.t.rep?' ↻':''}${x.t.rw>0&&!x.t.rd?`<span class="rwb">+${Number(x.t.rw)}</span>`:''}</b>${x.t.desc?`<small>${esc(x.t.desc)}</small>`:''}</div></div>`}
function vTasks(){
  const s=parse(sel),ws=addDays(s,-((s.getDay()+1)%7)),today=iso(new Date()),days=[...Array(7)].map((_,i)=>addDays(ws,i));
  const day=[];S.goals.forEach(g=>g.tasks.forEach(t=>{if(t.date===sel)day.push({t,g,k:'g|'+g.id+'|'+t.id})}));S.loose.forEach(t=>{if(t.date===sel)day.push({t,k:'l|'+t.id})});
  const frac=day.length?day.filter(x=>x.t.done).length/day.length:0,od=ovd();
  if(!od.length)backlog=false;
  const list=backlog?od.map(x=>({t:x.k,g:x.g,k:x.g?'g|'+x.g.id+'|'+x.k.id:'l|'+x.k.id})):day;
  const dots=k=>{const c=S.goals.filter(g=>!g.long&&g.tasks.some(t=>t.date===k)).map(gcol);if(S.loose.some(t=>t.date===k))c.push('var(--m)');return c.slice(0,3).map(x=>`<i style="--c:${x}"></i>`).join('')};
  return `<div class="wnav"><div class="grp2"><button class="ib sm" data-w="-7">${ic('r')}</button><span class="wn" data-act="cal">${weekNo(ws)}</span><button class="ib sm" data-w="7">${ic('l')}</button></div><button class="today" data-act="today">${new Date().getDate()}</button></div>
<section class="wk"><div class="goals">${bars(ws)}</div><div class="days">${days.map(d=>`<div class="dnm">${DN[d.getDay()]}</div>`).join('')}${days.map(d=>{const k=iso(d);return `<div class="dd"><button data-d="${k}" class="${k===sel?'sel':''}${k===today?' now':''}">${d.getDate()}</button><span class="dots">${dots(k)}</span></div>`}).join('')}</div></section>
<div class="prog"><span class="track"><i style="width:${frac*100}%"></i></span>${od.length?`<button class="pd${backlog?' on':''}" data-act="bl" aria-label="متراكمة"><i></i></button>`:'<span class="pd"></span>'}</div>
${startCard(today)}<div>${list.length?list.map(row).join(''):`<div class="empty">${ic('check')}</div>`}</div>`;
}

/* ---------- التقويم ---------- */
function vCal(){
  const off=(new Date(cy,cm,1,12).getDay()+1)%7,dim=new Date(cy,cm+1,0).getDate(),today=iso(new Date());
  let c='<i></i>'.repeat(off);
  for(let d=1;d<=dim;d++){const k=cy+'-'+pad(cm+1)+'-'+pad(d);const cs=S.goals.filter(g=>!g.long&&g.tasks.some(t=>t.date===k)).map(gcol);if(S.loose.some(t=>t.date===k))cs.push('var(--m)');
    const st=S.goals.filter(g=>g.start<=k&&k<=g.end).slice(0,2).map(g=>`<i style="--c:${gcol(g)}"></i>`).join('');
    c+=`<button class="mc${k===today?' now':''}${k===sel?' sel':''}" data-md="${k}">${d}<span class="dots">${cs.slice(0,3).map(x=>`<i style="--c:${x}"></i>`).join('')}</span><span class="mst">${st}</span></button>`}
  return `<div class="mh"><button class="ib" data-cy="-1">${ic('r')}</button><div class="mt"><b>${cy}</b><span>${MON[cm]}</span></div><button class="ib" data-cy="1">${ic('l')}</button></div>
<div class="chs">${MON.map((n,i)=>`<button class="ch${i===cm?' on':''}" data-mm="${i}">${n}</button>`).join('')}</div>
<div class="mg">${[6,0,1,2,3,4,5].map(i=>`<div class="dnm">${DN[i]}</div>`).join('')}</div><div class="mg">${c}</div>
<div class="hint">اضغط مطولًا على يوم لإضافة مهمة</div>`;
}

/* ---------- الأهداف ---------- */
function path(ts,done){
  const n=ts.length;if(!n)return '';
  const W=300,m=Math.min(n,14),s=ts.slice().sort((a,b)=>a.date<b.date?-1:1).slice(0,m);
  const xs=s.map((_,i)=>W-14-i*((W-52)/(m>1?m-1:1))),ys=s.map((_,i)=>22+9*Math.sin(i*1.25));
  let d='M'+xs[0]+' '+ys[0];for(let i=1;i<m;i++){d+=` Q${(xs[i-1]+xs[i])/2} ${ys[i-1]} ${xs[i]} ${ys[i]}`}
  const dx=xs[m-1]-34,all=ts.every(t=>t.done);
  return `<svg class="pth" viewBox="0 0 300 46"><path class="l" d="${d}"/>${s.map((t,i)=>`<circle class="n${t.done?' d':''}" cx="${xs[i]}" cy="${ys[i]}" r="5.5"/>`).join('')}<path class="door${all?' d':''}" d="M${dx} 38V20a8 8 0 0 1 16 0v18z"/></svg>`;
}
function vGoals(){
  const sh=(g,k)=>{const p=Math.round(prog(g)*100);return `<div class="${k?'kid':''}" data-g="${g.id}">${k?`<h4><span>${esc(g.title)}</span><span>${p}%</span></h4>`:`<h3><span>${esc(g.title)}</span><small>${p}%</small></h3>`}${path(tasksOf(g))}</div>`};
  const longs=S.goals.filter(g=>g.long),single=S.goals.filter(g=>!g.long&&!(g.parent&&S.goals.some(x=>x.id===g.parent)));
  const out=longs.map(L=>`<div class="card" style="border-color:color-mix(in srgb,${L.color} 45%,transparent)">${sh(L,0)}${kids(L).map(k=>sh(k,1)).join('')}</div>`).concat(single.map(g=>`<div class="card" style="border-color:color-mix(in srgb,${g.color} 45%,transparent)">${sh(g,0)}</div>`));
  return out.length?out.join(''):`<div class="empty">${ic('goal')}</div>`;
}

/* ---------- القوائم ---------- */
function sortedLists(){
  return S.lists.map((L,index)=>({L,index})).filter(x=>listShowArchived?!!x.L.archived:!x.L.archived).sort((a,b)=>Number(!!b.L.pinned)-Number(!!a.L.pinned)||(Number(a.L.order??a.index)-Number(b.L.order??b.index))).map(x=>x.L);
}
function vLists(){
  const visible=sortedLists();
  const active=S.lists.filter(L=>!L.archived).length,archived=S.lists.filter(L=>L.archived).length;
  const cards=visible.map(L=>{
    const incomplete=L.items.filter(i=>!i.done).length;
    return `<div class="card list-card${L.archived?' archived':''}"><h3><span>${L.pinned?'📌 ':''}${esc(L.title)} <small class="list-meta">${incomplete} غير مكتمل</small></span><span class="list-actions"><button class="ib sm" data-pin="${L.id}" aria-label="${L.pinned?'إلغاء تثبيت':'تثبيت'} القائمة">${L.pinned?'★':'☆'}</button><button class="ib sm" data-manage-list="${L.id}" aria-label="إدارة القائمة">⋯</button></span></h3>
${L.items.map(i=>`<div class="li${i.done?' done':''}"><button class="ck" data-tg="i|${L.id}|${i.id}" aria-label="${i.done?'إلغاء الإنجاز':'إنجاز العنصر'}">${ic('check')}</button><div class="tx"><b>${esc(i.title)}</b></div><button class="ib sm" data-ri="${L.id}|${i.id}" aria-label="حذف العنصر">${ic('x')}</button></div>`).join('')}
${L.archived?'':`<div class="addi"><input data-ni="${L.id}" placeholder="إضافة عنصر إلى ${esc(L.title)}" aria-label="عنصر جديد في ${esc(L.title)}"><button data-ai="${L.id}" aria-label="إضافة العنصر">${ic('plus')}</button></div>`}</div>`;
  }).join('');
  return `<div class="list-head"><h2>قوائمي</h2><div class="list-tools"><button class="list-tool${listShowArchived?' on':''}" data-show-archived="1">${listShowArchived?'القوائم المؤرشفة':'الأرشيف'}${listShowArchived?' ('+archived+')':''}</button><button class="list-tool" data-manage-all="1">إدارة</button></div></div>
${cards||`<div class="empty-state">${ic('list')}<b>${listShowArchived?'لا توجد قوائم مؤرشفة':'ابدأ بأول قائمة'}</b><p>${listShowArchived?'القوائم التي تؤرشفها ستظهر هنا.':'أنشئ قائمة للتسوق أو التعلم أو أي شيء تريد تنظيمه.'}</p>${listShowArchived?'':'<button class="btn" data-act="add-list">إنشاء قائمة</button>'}</div>`}
${!listShowArchived?`<button class="list-new" data-act="add-list">${ic('plus')} إنشاء قائمة جديدة</button>`:''}`;
}
function manageList(id){
  const L=S.lists.find(x=>x.id===id);if(!L)return;
  D={kind:'manage-list',id};
  show(`<h2>إدارة القائمة</h2><p class="hint" style="padding:0;text-align:right">${esc(L.title)}</p><button class="btn g" data-list-action="pin">${L.pinned?'إلغاء التثبيت':'تثبيت في الأعلى'}</button><button class="btn g" data-list-action="up">نقل لأعلى</button><button class="btn g" data-list-action="down">نقل لأسفل</button><button class="btn g" data-list-action="archive">${L.archived?'استعادة من الأرشيف':'أرشفة القائمة'}</button><button class="btn r" data-list-action="delete">${pend===id?'اضغط مرة أخرى لتأكيد الحذف':'حذف القائمة'}</button>`);
}
function manageAllLists(){
  D={kind:'manage-all-lists'};
  const rows=sortedLists().map((L,i)=>`<div class="li"><div class="tx"><b>${L.pinned?'📌 ':''}${esc(L.title)}</b><small>${L.items.filter(x=>!x.done).length} غير مكتمل</small></div><button class="ib sm" data-list-move="${L.id}|up" aria-label="نقل لأعلى">↑</button><button class="ib sm" data-list-move="${L.id}|down" aria-label="نقل لأسفل">↓</button><button class="ib sm" data-manage-list="${L.id}" aria-label="خيارات">⋯</button></div>`).join('');
  show(`<h2>إدارة القوائم</h2>${rows||'<div class="hint">لا توجد قوائم لإدارتها.</div>'}<button class="btn" data-act="add-list">إنشاء قائمة</button>`);
}


function vHabits(){
 const today=iso(new Date()),habits=S.habits||[],doneCount=habits.filter(x=>(x.doneDates||[]).includes(today)).length;
 return `<div class="mh"><div><h2 style="margin:0">عاداتي</h2><span style="color:var(--m);font-size:13px">${doneCount} من ${habits.length} مكتملة اليوم</span></div><button class="btn" data-habit-add>＋ عادة</button></div>
 ${habits.length?habits.map(x=>{const done=(x.doneDates||[]).includes(today);return `<div class="card" style="display:flex;align-items:center;gap:12px;margin-bottom:10px"><button class="ck${done?' on':''}" data-habit-toggle="${x.id}" aria-label="تسجيل العادة">${done?ic('check'):''}</button><div style="flex:1;min-width:0"><b style="${done?'text-decoration:line-through;opacity:.65':''}">${esc(x.title)}</b><div style="color:var(--m);font-size:12px">${esc(x.frequency||'يوميًا')} · ${(x.doneDates||[]).length} إنجاز${Number(x.focusReward)>0?` · مكافأة Focus: ${Number(x.focusReward)}`:''}</div></div><button class="ib sm" data-habit-widget="${x.id}" aria-label="عرض في الودجت" title="عرض في الودجت">${x.widget?'▣':'□'}</button><button class="ib sm" data-habit-edit="${x.id}" aria-label="تعديل">⋯</button></div>`}).join(''):'<div class="card hint">ابدأ بعادة صغيرة تريد الالتزام بها، وسجّل إنجازها كل يوم.</div>'}`;
}
function sheetHabit(id){
 const x=id?S.habits.find(y=>y.id===id):null;
 show(`<h2>${x?'تعديل العادة':'إضافة عادة'}</h2><label class="lb">اسم العادة</label><input class="big" id="habit-title" maxlength="70" placeholder="مثال: قراءة 10 صفحات" value="${esc(x?.title||'')}"><label class="lb">التكرار</label><select id="habit-frequency"><option ${!x||x.frequency==='يوميًا'?'selected':''}>يوميًا</option><option ${x?.frequency==='أسبوعيًا'?'selected':''}>أسبوعيًا</option></select><label class="lb">مكافأة Focus عند الإنجاز</label><input id="habit-reward" type="number" min="0" max="100000" step="0.5" inputmode="decimal" placeholder="0 = بدون مكافأة" value="${Number(x?.focusReward)||0}"><p class="hint" style="text-align:start">عند تسجيل إنجاز العادة، تُضاف هذه القيمة إلى رصيد Focus. عند التراجع عن الإنجاز، يُخصم المقدار الممكن من الرصيد.</p><div class="fl" style="margin-top:16px"><button class="btn" data-habit-save="${x?.id||''}">حفظ</button>${x?`<button class="btn" data-habit-delete="${x.id}">حذف</button>`:''}</div>`);
}
function toggleHabit(id){const x=S.habits.find(y=>y.id===id);if(!x)return;x.doneDates=x.doneDates||[];const today=iso(new Date()),i=x.doneDates.indexOf(today),reward=Math.max(0,Number(x.focusReward)||0);if(i>=0){x.doneDates.splice(i,1);if(reward>0)focusReward(-reward,'تراجع عن إنجاز العادة: '+x.title,'habit|'+id+'|'+today+'|undo')}else{x.doneDates.push(today);if(reward>0)focusReward(reward,'مكافأة العادة: '+x.title,'habit|'+id+'|'+today)}persist();render()}
function vFocus(){const active=(S.habits||[]).filter(h=>h.focusReward>0),today=iso(new Date()),done=active.filter(h=>(h.doneDates||[]).includes(today)).length;return `<div class="mh"><div><h2 style="margin:0">Focus</h2><span style="color:var(--m);font-size:13px">مساحة التركيز والمكافآت</span></div><button class="btn" data-focus-open>تفاصيل الرصيد والجلسات</button></div><div class="card"><b>العادات المرتبطة بالمكافآت</b><p class="hint" style="text-align:start">${active.length?`أنجزت ${done} من ${active.length} عادات لها مكافأة اليوم. سجّل الإنجاز من قسم العادات أو من الودجت؛ وسيُحدَّث رصيد Focus تلقائيًا.`:'افتح أي عادة وحدد قيمة «مكافأة Focus عند الإنجاز» لربطها بنظام التركيز.'}</p><button class="btn" data-tab="habits" style="width:100%">إدارة العادات</button></div><div class="card"><b>ابدأ بسرعة</b><div class="fl" style="margin-top:12px"><button class="btn" data-focus-open>جلسة التركيز</button><button class="btn" data-tab="tasks">مهام اليوم</button></div></div>`}
function render(){
  document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===tab));
  const T={tasks:'اليوم',cal:'التقويم',goals:'الأهداف',lists:'القوائم',habits:'العادات',focus:'Focus'};
  $('#ttl').textContent=T[tab];
  $('#main').innerHTML=tab==='tasks'?vTasks():tab==='cal'?vCal():tab==='goals'?vGoals():tab==='lists'?vLists():tab==='habits'?vHabits():vFocus();
}

/* ---------- النوافذ ---------- */
const show=h=>{$('#sheet').innerHTML=h;$('#ov').classList.add('on')};
const closeS=()=>{$('#ov').classList.remove('on');D=null};
const kindBar=a=>`<div class="fl">${[['task','مهمة'],['goal','هدف'],['list','قائمة']].map(([k,v])=>`<button class="ch${a===k?' on':''}" data-kind="${k}">${v}</button>`).join('')}</div>`;
function sheetTask(key){
  let t=null,isNew=!key;
  if(key){const p=key.split('|');t=p[0]==='g'?S.goals.find(x=>x.id===p[1]).tasks.find(x=>x.id===p[2]):S.loose.find(x=>x.id===p[1])}
  D={kind:'task',key,isNew,title:t?t.title:'',desc:t?t.desc||'':'',date:t?t.date:sel,goal:'',rep:t?t.rep||'':'',pr:t&&t.pr?1:0,rw:t&&t.rw?t.rw:0};drawTask();
}
function drawTask(err){
  const g=S.goals.filter(x=>!x.long);
  show(`${D.isNew?kindBar('task'):''}<input class="big" id="f-t" placeholder="ماذا تريد أن تنجز؟" value="${esc(D.title)}"><textarea id="f-d" rows="2" placeholder="وصف">${esc(D.desc)}</textarea>
<label class="lb">اليوم</label><input id="f-dt" type="date" value="${D.date}">
${D.isNew?'':`<div class="fl" style="margin-top:8px"><button class="ch" data-pp="1">غدًا</button><button class="ch" data-pp="7">بعد 7 أيام</button><button class="ch" data-pp="d">تاريخ محدد</button></div>`}
<label class="lb">التكرار</label><select id="f-r"><option value="">بدون</option><option value="d"${D.rep==='d'?' selected':''}>يوميًا</option><option value="w"${D.rep==='w'?' selected':''}>أسبوعيًا</option></select>
<label class="lb">مكافأة Focus (رصيد عند الإنجاز)</label><input id="f-rw" type="number" min="0" step="0.5" inputmode="decimal" placeholder="مثال: 5" value="${D.rw||''}">
<div class="fl" style="margin-top:8px"><button class="ch${D.pr?' on':''}" data-pr="1">★ مهمة مهمة</button></div>
${D.isNew?`<label class="lb">الوجهة</label><select id="f-g"><option value="">عادية</option>${g.map(x=>`<option value="${x.id}"${x.id===D.goal?' selected':''}>${esc(x.title)}</option>`).join('')}</select>`:''}
<div class="err">${err||''}</div><button class="btn" data-sv="task">${D.isNew?'إضافة':'حفظ'}</button>${D.isNew?'':`<button class="btn r" data-sv="deltask">${D.conf?'اضغط للتأكيد':'حذف'}</button>`}`);
}
function syncTask(){D.title=$('#f-t').value;D.desc=$('#f-d').value;D.date=$('#f-dt').value;const g=$('#f-g');if(g)D.goal=g.value;const r=$('#f-r');if(r)D.rep=r.value;const w=$('#f-rw');if(w)D.rw=parseFloat(w.value)||0}
const mkT=t=>{const o={id:uid(),title:t,desc:D.desc.trim(),date:D.date,done:false};if(D.rep)o.rep=D.rep;if(D.pr)o.pr=1;if(D.rw>0)o.rw=D.rw;return o};
function sheetGoal(id){
  const g=id&&S.goals.find(x=>x.id===id);
  D=g?{kind:'goal',...JSON.parse(JSON.stringify(g)),isNew:false}:{kind:'goal',id:uid(),title:'',color:PAL[S.goals.length%PAL.length],start:sel,end:iso(addDays(parse(sel),13)),tasks:[],long:false,parent:'',isNew:true};
  drawGoal();
}
function drawGoal(err){
  const d=D,longs=S.goals.filter(x=>x.long&&x.id!==d.id);d.tasks.sort((a,b)=>a.date<b.date?-1:1);
  show(`${d.isNew?kindBar('goal'):''}${d.isNew?`<div class="fl"><button class="ch${!d.long?' on':''}" data-gl="0">قصير المدى</button><button class="ch${d.long?' on':''}" data-gl="1">طويل المدى</button></div>`:''}
<input class="big" id="g-t" placeholder="اسم الهدف" value="${esc(d.title)}">
${d.long?'':`<label class="lb">ضمن هدف طويل المدى</label><select id="g-p"><option value="">بدون</option>${longs.map(x=>`<option value="${x.id}"${x.id===d.parent?' selected':''}>${esc(x.title)}</option>`).join('')}</select>`}
${d.parent?'':`<label class="lb">اللون</label><div class="cols">${PAL.map(c=>`<button data-col="${c}" class="${c===d.color?'on':''}" style="--c:${c}"></button>`).join('')}</div>`}
<div class="row2"><div><label class="lb">من</label><input id="g-s" type="date" value="${d.start}"></div><div><label class="lb">إلى</label><input id="g-e" type="date" value="${d.end}"></div></div>
${d.long?`<label class="lb">الأهداف القصيرة المرتبطة</label>${kids(d).map(k=>`<div class="mtk"><b>${esc(k.title)}</b><small>${Math.round(prog(k)*100)}%</small></div>`).join('')||'<div class="hint">اربط هدفًا قصيرًا من خانة "ضمن هدف طويل المدى"</div>'}`:
`<label class="lb">المهام</label>${d.tasks.map(t=>`<div class="mtk"><b>${esc(t.title)}</b><small>${t.date}</small><button class="ib sm" data-rt="${t.id}">${ic('x')}</button></div>`).join('')}<div class="row2" style="margin-top:8px"><input id="g-nt" placeholder="مهمة جديدة" value="${esc(d.nt||'')}"><input id="g-nd" type="date" value="${d.nd||d.start}"></div><button class="btn g" data-sv="gtask">+ مهمة</button>`}
<div class="err">${err||''}</div><button class="btn" data-sv="goal">حفظ</button>${d.isNew?'':`<button class="btn r" data-sv="delgoal">${d.conf?'اضغط للتأكيد':'حذف الهدف'}</button>`}`);
}
function syncGoal(){const d=D;d.title=$('#g-t').value;d.start=$('#g-s').value;d.end=$('#g-e').value;const p=$('#g-p');if(p)d.parent=p.value;const n=$('#g-nt');if(n){d.nt=n.value;d.nd=$('#g-nd').value}}
function sheetList(){D={kind:'list'};show(`${kindBar('list')}<input class="big" id="l-t" placeholder="اسم القائمة (مثال: التسوق)"><div class="err"></div><button class="btn" data-sv="list">إنشاء</button>`)}
function sheetAdd(k){k==='goal'?sheetGoal():k==='list'?sheetList():sheetTask()}
function sheetSet(){
  const sw=(k,t)=>`<div class="set"><span>${t}</span><button class="sw${pref(k)?' on':''}" data-pf="${k}"><i></i></button></div>`;
  show(`<h2>الإعدادات</h2>${sw('snd','الأصوات')}${sw('anim','الاحتفالات المتحركة')}<button class="btn g" data-act="exp">نسخ احتياطي (ملف)</button><button class="btn g" data-act="imp">استيراد من ملف</button><div class="logo"><img src="logo.png" alt=""><span>أهدافي · طريقك إلى الباب المضيء</span></div>`);
}
function exportFile(){
  if(hasA()){Android.exportBackup();return}
  const b=new Blob([JSON.stringify(S)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='ahdaf-backup-'+iso(new Date())+'.json';document.body.appendChild(a);a.click();a.remove();
}
function importFile(){if(hasA())Android.importBackup();else $('#file').click()}
$('#file').addEventListener('change',e=>{const f=e.target.files[0];if(!f)return;f.text().then(t=>{try{const s=JSON.parse(t);if(!confirm('سيتم استبدال بياناتك الحالية بمحتوى الملف. متابعة؟'))return;S.goals=s.goals||[];S.loose=s.loose||[];S.lists=s.lists||[];S.habits=s.habits||[];persist();closeS();render()}catch(x){}})});

function save(a){
  if(a==='task'){syncTask();const t=D.title.trim();if(!t)return drawTask('اكتب المهمة');if(!D.date)return drawTask('اختر اليوم');
    if(D.isNew){if(D.goal){const g=S.goals.find(x=>x.id===D.goal);if(D.date<g.start||D.date>g.end)return drawTask('اليوم خارج مدى الهدف');g.tasks.push(mkT(t))}else S.loose.push(mkT(t))}
    else{const p=D.key.split('|'),o=p[0]==='g'?S.goals.find(x=>x.id===p[1]).tasks.find(x=>x.id===p[2]):S.loose.find(x=>x.id===p[1]);o.title=t;o.desc=D.desc.trim();o.date=D.date;if(D.rep)o.rep=D.rep;else delete o.rep;if(D.pr)o.pr=1;else delete o.pr;if(D.rw>0)o.rw=D.rw;else delete o.rw}
    sel=D.date;tab='tasks';persist();closeS();render()}
  else if(a==='deltask'){if(!D.conf){D.conf=1;return drawTask()}const p=D.key.split('|');if(p[0]==='g'){const g=S.goals.find(x=>x.id===p[1]),i=g.tasks.findIndex(x=>x.id===p[2]),t=g.tasks[i],gid=g.id;g.tasks.splice(i,1);UNDO=()=>{const h=S.goals.find(x=>x.id===gid);if(h)h.tasks.splice(Math.min(i,h.tasks.length),0,t)}}else{const i=S.loose.findIndex(x=>x.id===p[1]),t=S.loose[i];S.loose.splice(i,1);UNDO=()=>{S.loose.splice(Math.min(i,S.loose.length),0,t)}}persist();closeS();render();toast('تم حذف المهمة',1)}
  else if(a==='gtask'){syncGoal();const t=(D.nt||'').trim();if(!t)return drawGoal('اكتب المهمة');if(!D.nd||D.nd<D.start||D.nd>D.end)return drawGoal('اليوم خارج مدى الهدف');D.tasks.push({id:uid(),title:t,date:D.nd,done:false});D.nt='';drawGoal()}
  else if(a==='goal'){syncGoal();if(!D.title.trim())return drawGoal('اكتب اسم الهدف');if(!D.start||!D.end||D.end<D.start)return drawGoal('تأكد من التواريخ');if(!D.long&&D.tasks.some(t=>t.date<D.start||t.date>D.end))return drawGoal('فيه مهام خارج المدى');
    const{kind,isNew,nt,nd,conf,...g}=D;g.title=g.title.trim();const i=S.goals.findIndex(x=>x.id===g.id);if(i<0)S.goals.push(g);else S.goals[i]=g;sel=g.start;persist();closeS();render()}
  else if(a==='delgoal'){if(!D.conf){D.conf=1;return drawGoal()}const gi=S.goals.findIndex(x=>x.id===D.id),g0=S.goals[gi],kidIds=S.goals.filter(x=>x.parent===D.id).map(x=>x.id);S.goals.forEach(x=>{if(x.parent===D.id)x.parent=''});S.goals.splice(gi,1);UNDO=()=>{S.goals.splice(Math.min(gi,S.goals.length),0,g0);S.goals.forEach(x=>{if(kidIds.includes(x.id))x.parent=g0.id})};persist();closeS();render();toast('تم حذف الهدف',1)}
  else if(a==='list'){const t=$('#l-t').value.trim();if(!t)return;S.lists.push({id:uid(),title:t,items:[]});tab='lists';persist();closeS();render()}
}
function moveList(id,dir){const visible=sortedLists(),from=visible.findIndex(x=>x.id===id),to=from+(dir==='up'?-1:1);if(from<0||to<0||to>=visible.length)return;const ids=visible.map(x=>x.id);[ids[from],ids[to]]=[ids[to],ids[from]];ids.forEach((key,index)=>{const item=S.lists.find(x=>x.id===key);if(item)item.order=index});persist();render()}
function addItem(id){const i=document.querySelector(`input[data-ni="${id}"]`),v=i?.value.trim();if(!v)return;const L=S.lists.find(x=>x.id===id);if(!L||L.archived)return;L.items.push({id:uid(),title:v,done:false});persist();render();const n=document.querySelector(`input[data-ni="${id}"]`);if(n)n.focus()}

/* ---------- الأحداث ---------- */
document.addEventListener('click',e=>{
  if(lpf){lpf=false;e.stopPropagation();e.preventDefault();return}
  const c=s=>e.target.closest(s);let el;
  if(e.target.id==='ov')closeS();
  else if(c('[data-focus-open]')){try{Android.openFocus(tab)}catch(x){}}
  else if(c('[data-un]'))doUndo();
  else if(el=c('[data-pp]'))postpone(el.dataset.pp);
  else if(c('[data-pr]')){syncTask();D.pr=D.pr?0:1;drawTask()}
  else if(c('[data-sk]')){skipN++;render()}
  else if(el=c('[data-tab]')){tab=el.dataset.tab;backlog=false;render()}
  else if(c('[data-habit-add]'))sheetHabit()
  else if(el=c('[data-habit-edit]'))sheetHabit(el.dataset.habitEdit)
  else if(el=c('[data-habit-widget]')){const x=S.habits.find(y=>y.id===el.dataset.habitWidget);if(x){x.widget=!x.widget;persist();render();toast(x.widget?'ستظهر العادة في الودجت':'تم إخفاء العادة من الودجت')}}
  else if(el=c('[data-habit-toggle]'))toggleHabit(el.dataset.habitToggle)
  else if(el=c('[data-habit-save]')){const title=$('#habit-title').value.trim(),frequency=$('#habit-frequency').value,focusReward=Math.max(0,Number($('#habit-reward').value)||0);if(!title){$('#habit-title').focus();return}const id=el.dataset.habitSave;if(id){const x=S.habits.find(y=>y.id===id);if(x){x.title=title;x.frequency=frequency;x.focusReward=focusReward}}else S.habits.push({id:uid(),title,frequency,focusReward,doneDates:[]});persist();closeS();render()}
  else if(el=c('[data-habit-delete]')){S.habits=S.habits.filter(x=>x.id!==el.dataset.habitDelete);persist();closeS();render()}
  else if(el=c('[data-tg]')){const p=el.dataset.tg.split('|');tog(p[0],p[1],p[2])}
  else if(el=c('[data-w]')){sel=iso(addDays(parse(sel),+el.dataset.w));render()}
  else if(el=c('[data-act]')){const a=el.dataset.act;
    if(a==='today'){sel=iso(new Date());render()}else if(a==='cal'){const s=parse(sel);cy=s.getFullYear();cm=s.getMonth();tab='cal';render()}
    else if(a==='bl'){backlog=!backlog;render()}else if(a==='add-list')sheetList();else if(a==='add')sheetAdd('task');else if(a==='srch')sheetSearch();else if(a==='set')sheetSet();else if(a==='exp')exportFile();else if(a==='imp')importFile()}
  else if(el=c('[data-d]')){sel=el.dataset.d;render()}
  else if(el=c('[data-md]')){sel=el.dataset.md;tab='tasks';render()}
  else if(el=c('[data-cy]')){cm+=+el.dataset.cy;if(cm>11){cm=0;cy++}if(cm<0){cm=11;cy--}render()}
  else if(el=c('[data-mm]')){cm=+el.dataset.mm;render()}
  else if(el=c('[data-ed]'))sheetTask(el.dataset.ed);
  else if(el=c('[data-g]'))sheetGoal(el.dataset.g);
  else if(el=c('[data-kind]'))sheetAdd(el.dataset.kind);
  else if(el=c('[data-gl]')){syncGoal();D.long=el.dataset.gl==='1';if(D.long)D.parent='';drawGoal()}
  else if(el=c('[data-col]')){syncGoal();D.color=el.dataset.col;drawGoal()}
  else if(el=c('[data-rt]')){syncGoal();D.tasks=D.tasks.filter(t=>t.id!==el.dataset.rt);drawGoal()}
  else if(el=c('[data-sv]'))save(el.dataset.sv);
  else if(el=c('[data-pf]')){const k=el.dataset.pf;setPref(k,!pref(k));if(k==='snd'&&pref(k))chime(1);sheetSet()}
  else if(el=c('[data-show-archived]')){listShowArchived=!listShowArchived;pend=null;render()}
  else if(el=c('[data-manage-all]'))manageAllLists()
  else if(el=c('[data-manage-list]'))manageList(el.dataset.manageList)
  else if(el=c('[data-pin]')){const L=S.lists.find(x=>x.id===el.dataset.pin);if(L){L.pinned=!L.pinned;persist();render()}}
  else if(el=c('[data-list-move]')){const [id,dir]=el.dataset.listMove.split('|');moveList(id,dir);manageAllLists()}
  else if(el=c('[data-list-action]')){const action=el.dataset.listAction,L=S.lists.find(x=>x.id===D?.id);if(!L)return; if(action==='pin'){L.pinned=!L.pinned;persist();manageList(L.id)}else if(action==='archive'){L.archived=!L.archived;pend=null;persist();closeS();render();toast(L.archived?'تمت أرشفة القائمة':'تمت استعادة القائمة')}else if(action==='up'||action==='down'){moveList(L.id,action);manageList(L.id)}else if(action==='delete'){if(pend!==L.id){pend=L.id;manageList(L.id);return}const ix=S.lists.findIndex(x=>x.id===L.id),old=S.lists[ix];S.lists.splice(ix,1);UNDO=()=>S.lists.splice(Math.min(ix,S.lists.length),0,old);pend=null;persist();closeS();render();toast('تم حذف القائمة',1)}}
  else if(el=c('[data-ai]'))addItem(el.dataset.ai);
  else if(el=c('[data-ri]')){const[l,i]=el.dataset.ri.split('|'),L=S.lists.find(x=>x.id===l);const ix=L.items.findIndex(x=>x.id===i),it=L.items[ix];L.items.splice(ix,1);UNDO=()=>{const M=S.lists.find(x=>x.id===l);if(M)M.items.splice(Math.min(ix,M.items.length),0,it)};persist();render();toast('تم حذف العنصر',1)}
},true);
document.addEventListener('input',e=>{if(e.target&&e.target.id==='q-t')drawSearch(e.target.value)});
document.addEventListener('change',e=>{if(D&&D.kind==='goal'&&e.target.id==='g-p'){syncGoal();drawGoal()}});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.dataset&&e.target.dataset.ni)addItem(e.target.dataset.ni)});
let lpT=null;
const lpStart=e=>{const d=e.target.closest('[data-d],[data-md]');clearTimeout(lpT);if(d)lpT=setTimeout(()=>{lpf=true;try{if(navigator.vibrate)navigator.vibrate(20)}catch(x){}sel=d.dataset.d||d.dataset.md;sheetTask()},520)};
document.addEventListener('touchstart',lpStart,{passive:true});
['touchmove','touchend','touchcancel'].forEach(t=>document.addEventListener(t,()=>clearTimeout(lpT),{passive:true}));
document.addEventListener('contextmenu',e=>{if(e.target.closest('[data-d],[data-md]'))e.preventDefault()});
let sx=0,sy=0;
document.addEventListener('touchstart',e=>{sx=e.touches[0].clientX;sy=e.touches[0].clientY},{passive:true});
document.addEventListener('touchend',e=>{
  if($('#ov').classList.contains('on'))return;
  const t=e.changedTouches[0],dx=t.clientX-sx,dy=t.clientY-sy;
  if(Math.abs(dx)<70||Math.abs(dx)<Math.abs(dy)*1.6)return;
  if(tab==='tasks'&&e.target.closest('.wk')){sel=iso(addDays(parse(sel),dx>0?7:-7));render();return}
  if(tab==='cal'&&e.target.closest('.mg')){cm+=dx>0?1:-1;if(cm>11){cm=0;cy++}if(cm<0){cm=11;cy--}render();return}
  if(e.target.closest('input,textarea,select,button,[contenteditable="true"]'))return;
  const tabs=['tasks','cal','goals','lists','habits','focus'],i=tabs.indexOf(tab),next=dx<0?i+1:i-1;
  if(i<0||next<0||next>=tabs.length)return;tab=tabs[next];backlog=false;render();
},{passive:true});
window.addEventListener('message',e=>{
  let m=e.data;
  if(typeof m==='string'){try{m=JSON.parse(m)}catch(_){return}}
  if(!m||typeof m.type!=='string')return;
  if(m.type==='focus_changed'){
    window.dispatchEvent(new CustomEvent('focus_changed',{detail:m}));
    render();
  }else if(m.type==='focus_returned'){
    if(['tasks','cal','goals','lists','habits','focus'].includes(m.tab))tab=m.tab;
    render();
  }else if(['data_changed','list_added','widget_opened'].includes(m.type)){
    const keepTab=tab,keepSel=sel;
    load();tab=keepTab;sel=keepSel;
    if(m.type==='widget_opened'&&['tasks','cal','goals','lists','habits','focus'].includes(m.tab))tab=m.tab;
    render();
  }
});
load();render();

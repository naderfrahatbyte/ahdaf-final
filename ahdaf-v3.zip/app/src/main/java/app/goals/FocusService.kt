package app.goals

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

// مراقبة التطبيق المفتوح فعليًا في الواجهة لاحتساب الرصيد، وحظر التطبيقات المستهلكة عند نفاده.
// الموثوقية: التطبيق الحالي يُقرأ من النافذة النشطة كل ثانية (لا نعتمد على الأحداث وحدها)،
// وكل خطوة محمية من الاستثناءات حتى لا تتوقف الخدمة أو يعطّلها النظام بسبب تعطّل.
class FocusService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var cur = ""
    private var last = 0L
    private var lastBlock = 0L
    private var lastSheet = 0L
    private var lastTick = 0L
    private var n = 0
    private var registered = false
    @Volatile private var ignore: Set<String> = emptySet()

    // قراءة النافذة النشطة تتم في خيط خلفي: إن تأخر النظام أو التطبيق المفتوح في الرد لا يتجمّد التطبيق ولا المؤقّت.
    private var worker: android.os.HandlerThread? = null
    private var wh: Handler? = null
    @Volatile private var fg = ""
    @Volatile private var screenOn = true
    private val poll = object : Runnable {
        override fun run() {
            try {
                if (screenOn) {
                    var node: AccessibilityNodeInfo? = null
                    try {
                        node = rootInActiveWindow
                        val p = node?.packageName?.toString()
                        if (p != null && p !in ignore) fg = p
                    } finally {
                        try {
                            node?.recycle()
                        } catch (e: Exception) {
                        }
                    }
                }
            } catch (e: Throwable) {
            }
            wh?.postDelayed(this, 1000)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Throwable) {
            }
            lastTick = SystemClock.elapsedRealtime()
            h.postDelayed(this, 1000)
        }
    }

    private val screen = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                // عند تشغيل الشاشة نبدأ العدّ من الآن حتى لا يُحتسب وقت الإطفاء
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    last = SystemClock.elapsedRealtime()
                    screenOn = true
                }
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    cur = ""
                    fg = ""
                    FocusStore.save(true)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        FocusStore.init(this)
        refreshIgnore()
        last = SystemClock.elapsedRealtime()
        if (!registered) {
            try {
                val f = IntentFilter()
                f.addAction(Intent.ACTION_SCREEN_ON)
                f.addAction(Intent.ACTION_SCREEN_OFF)
                f.addAction(Intent.ACTION_USER_PRESENT)
                registerReceiver(screen, f)
                registered = true
            } catch (e: Exception) {
            }
        }
        try {
            screenOn = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        } catch (e: Exception) {
        }
        if (worker == null) {
            val t = android.os.HandlerThread("focus-fg")
            t.start()
            worker = t
            wh = Handler(t.looper)
        }
        wh?.removeCallbacks(poll)
        wh?.post(poll)
        h.removeCallbacks(tick)
        h.post(tick)
    }

    private fun refreshIgnore() {
        val s = HashSet<String>()
        s.add("com.android.systemui")
        s.add("android")
        try {
            val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            for (i in im.enabledInputMethodList) s.add(i.packageName)
        } catch (e: Exception) {
        }
        ignore = s
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try {
            // حارس: إن توقف المؤقّت لأي سبب نعيد تشغيله
            if (SystemClock.elapsedRealtime() - lastTick > 5000) {
                h.removeCallbacks(tick)
                h.post(tick)
            }
            if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
            val p = e.packageName?.toString() ?: return
            if (p in ignore) return
            fg = p
            if (p != cur) {
                cur = p
                if (FocusStore.spendApp(cur) != null && FocusStore.earnApp(cur) == null && FocusStore.bal <= 0.0) block()
            }
        } catch (x: Throwable) {
        }
    }

    private fun step() {
        val now = SystemClock.elapsedRealtime()
        val dt = now - last
        last = now
        FocusStore.hb = now
        if (++n % 60 == 0) refreshIgnore()
        FocusStore.save()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        // لا احتساب والشاشة مطفأة أو مقفلة (منع احتساب الخلفية)
        if (!pm.isInteractive || km.isKeyguardLocked) {
            screenOn = false
            cur = ""
            fg = ""
            return
        }
        screenOn = true
        val f = fg
        if (f.isNotEmpty()) cur = f
        FocusStore.curPkg = cur
        if (cur.isEmpty()) return
        // سقف للفارق الزمني حتى لا يُحتسب الوقت مرتين أو دفعة واحدة بعد تعليق النظام
        val sec = dt.coerceIn(0L, 6000L) / 1000.0
        val e = FocusStore.earnApp(cur)
        if (e != null) {
            FocusStore.use(e, sec)
            FocusStore.add(e.rate * sec / 60.0, e.name, "e:" + cur, true)
            return
        }
        val s = FocusStore.spendApp(cur) ?: return
        if (FocusStore.bal <= 0.0) {
            block()
            return
        }
        FocusStore.use(s, sec)
        FocusStore.add(-s.rate * sec / 60.0, s.name, "s:" + cur, true)
        if (FocusStore.bal <= 0.0) block()
    }

    // الحظر: إخراج المستخدم للشاشة الرئيسية، ويتكرر عند كل قراءة إن عاد للتطبيق نفسه
    private fun block() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlock < 1200) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        try {
            Toast.makeText(this, T("انتهى رصيد Focus", "Focus credit is over"), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
        if (now - lastSheet > 8000) {
            lastSheet = now
            try {
                val i = Intent(this, FocusBlockActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacks(tick)
        wh?.removeCallbacks(poll)
        try {
            worker?.quitSafely()
        } catch (e: Exception) {
        }
        worker = null
        wh = null
        if (registered) {
            try {
                unregisterReceiver(screen)
            } catch (e: Exception) {
            }
            registered = false
        }
        FocusStore.hb = 0L
        FocusStore.save(true)
        super.onDestroy()
    }

    companion object {
        fun enabled(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(c, FocusService::class.java)
            for (x in s.split(':')) {
                val cn = ComponentName.unflattenFromString(x) ?: continue
                if (cn == me) return true
            }
            return false
        }
    }
}


// Keeps an active habit session visible and recoverable. Duration itself is derived from elapsedRealtime,
// so the service does not poll or hold a long-running wake lock while the device sleeps.
class FocusTimerService : android.app.Service() {
    private val checkpointHandler = Handler(Looper.getMainLooper())
    private val checkpointTick = object : Runnable {
        override fun run() {
            FocusStore.checkpointSession(this@FocusTimerService)
            val s = FocusStore.session
            if (s != null && s.state == "running") checkpointHandler.postDelayed(this, 30_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Lang.load(this)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(android.app.NotificationChannel("focus_session", T("جلسة Focus", "Focus session"), android.app.NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Lang.load(this)
        FocusStore.init(this)
        FocusStore.reconcileSession(this)
        val session = FocusStore.session
        if (session == null || session.state != "running") {
            stopSelf()
            return START_NOT_STICKY
        }
        val habit = FocusStore.habits.firstOrNull { it.id == session.habitId }
        val title = habit?.title ?: T("جلسة تركيز نشطة", "Active focus session")
        val open = Intent(this, FocusActivity::class.java).putExtra("from", "notification")
        val pending = android.app.PendingIntent.getActivity(this, 734, open, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
        val notification = buildNotification(title, pending)
        startForeground(734, notification)
        checkpointHandler.removeCallbacks(checkpointTick)
        checkpointHandler.postDelayed(checkpointTick, 30_000L)
        return START_STICKY
    }

    override fun onDestroy() {
        checkpointHandler.removeCallbacks(checkpointTick)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    @Suppress("DEPRECATION")
    private fun buildNotification(title: String, pending: android.app.PendingIntent): android.app.Notification {
        val builder = if (android.os.Build.VERSION.SDK_INT >= 26)
            android.app.Notification.Builder(this, "focus_session")
        else android.app.Notification.Builder(this)
        return builder.setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(T("جلسة Focus مستمرة", "Focus session in progress"))
            .setContentText(title).setContentIntent(pending).setOngoing(true).setOnlyAlertOnce(true).build()
    }
}

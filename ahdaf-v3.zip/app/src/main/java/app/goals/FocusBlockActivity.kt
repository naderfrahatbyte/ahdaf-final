package app.goals

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.widget.LinearLayout

// شاشة الحظر عند نفاد الرصيد
class FocusBlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        FocusStore.init(this)
        val pal = PalGen.focus()
        fun dp(v: Int): Int = Ui.dp(this, v)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(20), dp(20), dp(20), dp(16))
        root.addView(Ui.tv(this, T("انتهى رصيدك", "You're out of credit"), 20f, pal.fg, true))
        val sub = Ui.tv(this, T("اكسب رصيدًا من التطبيقات المنتجة أو العادات ثم ارجع.", "Earn credit from productive apps or habits, then come back."), 14f, pal.muted)
        root.addView(sub, Ui.lp(Ui.MP, Ui.WC, dp(8)))
        val open = Ui.btn(this, T("فتح Focus", "Open Focus"), pal.accent, Color.parseColor("#1a1224"))
        open.setOnClickListener {
            startActivity(Intent(this, FocusActivity::class.java).putExtra("from", "block"))
            finish()
        }
        root.addView(open, Ui.lp(Ui.MP, Ui.WC, dp(18)))
        val close = Ui.btn(this, T("إغلاق", "Close"), Color.TRANSPARENT, pal.muted)
        close.gravity = Gravity.CENTER
        close.setOnClickListener { finish() }
        root.addView(close, Ui.lp(Ui.MP, Ui.WC, dp(6)))
        setContentView(root)
        Glass.apply(this, pal, 0.86f)
    }
}

package app.goals

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import android.os.Build
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

// تطبيق منتج/مستهلك مع معدّل الدقيقة (rate)
class FApp(val pkg: String, var name: String, var rate: Double, var today: Double = 0.0)

// عادة: kind 0 = مكافأة يدوية، 1 = لكل دقيقة، 2 = مكافأة ثابتة
class FHabit(val id: String, var title: String, var kind: Int, var value: Double, var last: Long = 0L, var targetMinutes: Int = 25)

class FSession(var habitId: String, var state: String, var accumulatedMs: Long, var startedElapsedMs: Long, var bootCount: Int, var wallStartMs: Long)

class FLog(var ts: Long, var delta: Double, val label: String, val ref: String)

// بيانات Focus محلية في SharedPreferences منفصلة ("focus") دون المساس ببيانات الأهداف
object FocusStore {
    private var ctx: Context? = null
    var bal = 0.0
    var cap = 0.0 // الحد اليومي للمكافآت (0 = بلا حد)
    var hb = 0L // نبض الخدمة (elapsedRealtime لآخر قراءة ناجحة)
    var curPkg = ""
    private var dayKey = 0
    private var earnedToday = 0.0
    private var spentToday = 0.0
    val earn = ArrayList<FApp>()
    val spend = ArrayList<FApp>()
    val habits = ArrayList<FHabit>()
    val log = ArrayList<FLog>()
    var session: FSession? = null
    private var dirty = false
    private var lastSave = 0L
    private var lastWallClockMs = 0L
    private var lastElapsedClockMs = 0L

    fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        try {
            val raw = ctx!!.getSharedPreferences("focus", 0).getString("d", "") ?: ""
            if (raw.isNotEmpty()) fromJson(JSONObject(raw))
        } catch (e: Exception) {
        }
    }

    private fun fromJson(o: JSONObject) {
        bal = o.optDouble("bal", 0.0).coerceAtLeast(0.0)
        cap = o.optDouble("cap", 0.0).coerceAtLeast(0.0)
        dayKey = o.optInt("dk", 0)
        earnedToday = o.optDouble("et", 0.0)
        spentToday = o.optDouble("st", 0.0)
        lastWallClockMs = o.optLong("clockWall", 0L)
        lastElapsedClockMs = o.optLong("clockElapsed", 0L)
        earn.clear()
        spend.clear()
        habits.clear()
        log.clear()
        session = null
        val so = o.optJSONObject("session")
        if (so != null) session = FSession(so.optString("h"), so.optString("s", "paused"), so.optLong("a", 0L).coerceAtLeast(0L), so.optLong("e", 0L).coerceAtLeast(0L), so.optInt("b", -1), so.optLong("w", 0L))
        val ea = o.optJSONArray("earn") ?: JSONArray()
        for (i in 0 until ea.length()) {
            val x = ea.getJSONObject(i)
            earn.add(FApp(x.getString("p"), x.optString("n"), x.optDouble("r", 1.0), x.optDouble("ut", 0.0)))
        }
        val sa = o.optJSONArray("spend") ?: JSONArray()
        for (i in 0 until sa.length()) {
            val x = sa.getJSONObject(i)
            spend.add(FApp(x.getString("p"), x.optString("n"), x.optDouble("r", 1.0), x.optDouble("ut", 0.0)))
        }
        val ha = o.optJSONArray("habits") ?: JSONArray()
        for (i in 0 until ha.length()) {
            val x = ha.getJSONObject(i)
            habits.add(FHabit(x.getString("id"), x.optString("t"), x.optInt("k", 2), x.optDouble("v", 1.0), x.optLong("lt"), x.optInt("tm", 25).coerceIn(1, 600)))
        }
        val la = o.optJSONArray("log") ?: JSONArray()
        for (i in 0 until la.length()) {
            val x = la.getJSONObject(i)
            log.add(FLog(x.optLong("ts"), x.optDouble("d", 0.0), x.optString("l"), x.optString("r")))
        }
    }

    private fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("bal", bal)
        o.put("cap", cap)
        o.put("dk", dayKey)
        o.put("et", earnedToday)
        o.put("st", spentToday)
        o.put("clockWall", lastWallClockMs)
        o.put("clockElapsed", lastElapsedClockMs)
        val ea = JSONArray()
        for (a in earn) ea.put(JSONObject().put("p", a.pkg).put("n", a.name).put("r", a.rate).put("ut", a.today))
        o.put("earn", ea)
        val sa = JSONArray()
        for (a in spend) sa.put(JSONObject().put("p", a.pkg).put("n", a.name).put("r", a.rate).put("ut", a.today))
        o.put("spend", sa)
        val ha = JSONArray()
        for (h in habits) ha.put(JSONObject().put("id", h.id).put("t", h.title).put("k", h.kind).put("v", h.value).put("lt", h.last).put("tm", h.targetMinutes))
        o.put("habits", ha)
        val la = JSONArray()
        for (l in log) la.put(JSONObject().put("ts", l.ts).put("d", l.delta).put("l", l.label).put("r", l.ref))
        o.put("log", la)
        val se = session
        if (se != null) o.put("session", JSONObject().put("h", se.habitId).put("s", se.state).put("a", se.accumulatedMs).put("e", se.startedElapsedMs).put("b", se.bootCount).put("w", se.wallStartMs))
        return o
    }

    // للنسخ الاحتياطي والاستعادة
    fun snapshot(c: Context): JSONObject {
        init(c)
        return toJson()
    }

    fun restore(c: Context, o: JSONObject) {
        init(c)
        try {
            fromJson(o)
            dirty = true
            save(true)
        } catch (e: Exception) {
        }
    }

    fun save(force: Boolean = false) {
        val c = ctx ?: return
        if (!force) {
            if (!dirty) return
            if (SystemClock.elapsedRealtime() - lastSave < 5000) return
        }
        c.getSharedPreferences("focus", 0).edit().putString("d", toJson().toString()).apply()
        dirty = false
        lastSave = SystemClock.elapsedRealtime()
    }

    private fun bootCount(c: Context): Int = try { Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, 0) } catch (_: Exception) { 0 }

    fun reconcileSession(c: Context) {
        val s = session ?: return
        val boot = bootCount(c)
        if (s.state == "running" && (s.bootCount != boot || s.startedElapsedMs > SystemClock.elapsedRealtime())) {
            s.state = "paused"
            s.startedElapsedMs = 0L
            s.bootCount = boot
            save(true)
        }
    }

    fun elapsedSessionMs(): Long {
        val s = session ?: return 0L
        val live = if (s.state == "running") (SystemClock.elapsedRealtime() - s.startedElapsedMs).coerceAtLeast(0L) else 0L
        return (s.accumulatedMs + live).coerceAtLeast(0L)
    }

    fun startSession(c: Context, habitId: String) {
        session = FSession(habitId, "running", 0L, SystemClock.elapsedRealtime(), bootCount(c), System.currentTimeMillis())
        save(true)
        startTimerService(c)
    }

    fun pauseSession() {
        val s = session ?: return
        if (s.state != "running") return
        s.accumulatedMs = elapsedSessionMs()
        s.startedElapsedMs = 0L
        s.state = "paused"
        save(true)
        stopTimerService()
    }

    fun resumeSession(c: Context) {
        val s = session ?: return
        if (s.state != "paused") return
        s.startedElapsedMs = SystemClock.elapsedRealtime()
        s.wallStartMs = System.currentTimeMillis()
        s.bootCount = bootCount(c)
        s.state = "running"
        save(true)
        ctx?.let { startTimerService(it) }
    }

    fun checkpointSession(c: Context) {
        val s = session ?: return
        if (s.state != "running") return
        s.accumulatedMs = elapsedSessionMs()
        s.startedElapsedMs = SystemClock.elapsedRealtime()
        s.wallStartMs = System.currentTimeMillis()
        s.bootCount = bootCount(c)
        save(true)
    }

    fun completeSession() {
        val s = session ?: return
        if (s.state == "running") s.accumulatedMs = elapsedSessionMs()
        s.startedElapsedMs = 0L
        s.state = "completed"
        save(true)
        stopTimerService()
    }

    fun clearSession() { session = null; save(true); stopTimerService() }

    private fun startTimerService(c: Context) {
        try {
            val i = Intent(c, FocusTimerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        } catch (_: Exception) { /* The monotonic persisted timer remains usable if the OS rejects FGS start. */ }
    }

    private fun stopTimerService() {
        val c = ctx ?: return
        try { c.stopService(Intent(c, FocusTimerService::class.java)) } catch (_: Exception) {}
    }

    private fun logTimestamp(): Pair<Long, Boolean> {
        val wall = System.currentTimeMillis()
        val elapsed = SystemClock.elapsedRealtime()
        if (lastWallClockMs == 0L || lastElapsedClockMs == 0L) {
            lastWallClockMs = wall
            lastElapsedClockMs = elapsed
            return Pair(wall, false)
        }
        val wallDelta = wall - lastWallClockMs
        val elapsedDelta = elapsed - lastElapsedClockMs
        val jumped = abs(wallDelta - elapsedDelta) > 120_000L
        lastWallClockMs = wall
        lastElapsedClockMs = elapsed
        return Pair(wall, jumped)
    }

    fun earnApp(pkg: String): FApp? = earn.firstOrNull { it.pkg == pkg }
    fun spendApp(pkg: String): FApp? = spend.firstOrNull { it.pkg == pkg }

    // يضيف/يخصم من الرصيد المشترك؛ لا يصبح الرصيد سالبًا أبدًا. يعيد المقدار المطبّق فعلًا.
    private fun roll() {
        val t = todayDay()
        if (dayKey != t) {
            dayKey = t
            earnedToday = 0.0
            spentToday = 0.0
            for (a in earn) a.today = 0.0
            for (a in spend) a.today = 0.0
            dirty = true
        }
    }

    // الوقت الفعلي المستهلك اليوم لكل تطبيق (بالثواني)
    fun use(a: FApp, sec: Double) {
        roll()
        a.today += sec
        dirty = true
    }

    fun earnedNow(): Double {
        roll()
        return earnedToday
    }

    fun spentNow(): Double {
        roll()
        return spentToday
    }

    fun capReached(): Boolean {
        roll()
        return cap > 0.0 && earnedToday >= cap - 1e-9
    }

    // الحد اليومي يقيّد المكاسب فقط (من التطبيقات والعادات)، ولا يقيّد الخصم
    fun add(delta: Double, label: String, ref: String, merge: Boolean): Double {
        roll()
        var d = delta
        if (d > 0 && cap > 0.0) d = Math.min(d, Math.max(0.0, cap - earnedToday))
        val nb = (bal + d).coerceAtLeast(0.0)
        val applied = nb - bal
        if (Math.abs(applied) < 1e-9) return 0.0
        bal = nb
        if (applied > 0) earnedToday += applied else spentToday -= applied
        val (now, clockJump) = logTimestamp()
        val top = log.firstOrNull()
        if (merge && !clockJump && top != null && top.ref == ref && now >= top.ts && now - top.ts < 600000L) {
            top.delta += applied
            top.ts = now
        } else {
            log.add(0, FLog(now, applied, label, ref))
            while (log.size > 200) log.removeAt(log.size - 1)
        }
        dirty = true
        save(!merge)
        return applied
    }

    fun fmt(x: Double): String {
        val r = Math.round(x * 10) / 10.0
        return if (r == Math.floor(r)) r.toLong().toString() else String.format(Locale.US, "%.1f", r)
    }

    fun fmtFloor(x: Double): String = fmt(Math.floor(x * 10) / 10.0)
}

// تحويل رقم مكتوب بأرقام عربية أو فاصلة عربية
fun parseNum(s: String): Double? {
    val sb = StringBuilder()
    for (ch in s.trim()) {
        when {
            ch in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
            ch == '٫' || ch == '،' || ch == ',' -> sb.append('.')
            else -> sb.append(ch)
        }
    }
    return sb.toString().toDoubleOrNull()
}

package app.goals

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.widget.LinearLayout

// شاشة الحظر عند نفاد الرصيد
class FocusBlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        FocusStore.init(this)
        val pal = PalGen.focus()
        fun dp(v: Int): Int = Ui.dp(this, v)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(20), dp(20), dp(20), dp(16))
        root.addView(Ui.tv(this, T("انتهى رصيدك", "You're out of credit"), 20f, pal.fg, true))
        val sub = Ui.tv(this, T("اكسب رصيدًا من التطبيقات المنتجة أو العادات ثم ارجع.", "Earn credit from productive apps or habits, then come back."), 14f, pal.muted)
        root.addView(sub, Ui.lp(Ui.MP, Ui.WC, dp(8)))
        val open = Ui.btn(this, T("فتح Focus", "Open Focus"), pal.accent, Color.parseColor("#1a1224"))
        open.setOnClickListener {
            startActivity(Intent(this, FocusActivity::class.java).putExtra("from", "block"))
            finish()
        }
        root.addView(open, Ui.lp(Ui.MP, Ui.WC, dp(18)))
        // فتح طوارئ: 5 دقائق تُسدَّد تكلفتها من المكاسب القادمة
        val pkg = intent?.getStringExtra("pkg") ?: ""
        val app = FocusStore.spendApp(pkg)
        if (app != null) {
            if (FocusStore.canPass()) {
                val em = Ui.btn(this, T("فتح طوارئ 5 دقائق", "Emergency pass · 5 min"), Color.TRANSPARENT, pal.fg)
                em.setOnClickListener {
                    if (FocusStore.startPass(app)) {
                        MainActivity.notifyFocusChanged()
                        try {
                            val li = packageManager.getLaunchIntentForPackage(pkg)
                            if (li != null) startActivity(li)
                        } catch (e: Exception) {
                        }
                    }
                    finish()
                }
                root.addView(em, Ui.lp(Ui.MP, Ui.WC, dp(8)))
                root.addView(Ui.tv(this, T("تُخصم تكلفتها (", "Its cost (") + FocusStore.fmt(app.rate * 5.0) + T(") من مكاسبك القادمة.", ") is taken from your next earnings."), 12f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(2)))
            } else if (FocusStore.debt > 0.05) {
                root.addView(Ui.tv(this, T("عليك دين طوارئ (", "You owe an emergency debt (") + FocusStore.fmt(FocusStore.debt) + T(")؛ اكسبه أولًا لتتمكن من فتح جديد.", "); earn it back to unlock another pass."), 12f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(8)))
            }
        }
        val close = Ui.btn(this, T("إغلاق", "Close"), Color.TRANSPARENT, pal.muted)
        close.gravity = Gravity.CENTER
        close.setOnClickListener { finish() }
        root.addView(close, Ui.lp(Ui.MP, Ui.WC, dp(6)))
        setContentView(root)
        Glass.apply(this, pal, 0.86f)
    }
}

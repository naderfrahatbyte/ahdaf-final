package app.goals

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HabitWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == PREV || intent.action == NEXT) {
            val prefs = context.getSharedPreferences("habit_widget", 0)
            val ids = selected(context)
            if (ids.isNotEmpty()) {
                var i = prefs.getInt("index", 0)
                i = if (intent.action == NEXT) (i + 1) % ids.size else (i - 1 + ids.size) % ids.size
                prefs.edit().putInt("index", i).apply()
            }
            refresh(context)
        }
    }
    companion object {
        const val PREV = "app.goals.HABIT_WIDGET_PREV"
        const val NEXT = "app.goals.HABIT_WIDGET_NEXT"
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, HabitWidget::class.java))
            ids.forEach { update(context, manager, it) }
        }
        private fun selected(context: Context): List<Pair<String, String>> {
            val raw = context.getSharedPreferences("g", 0).getString("d", "") ?: ""
            return try {
                val habits = JSONObject(raw).optJSONArray("habits") ?: return emptyList()
                (0 until habits.length()).mapNotNull { i ->
                    val h = habits.optJSONObject(i) ?: return@mapNotNull null
                    if (h.optBoolean("widget", false)) (h.optString("id") to h.optString("title")) else null
                }
            } catch (_: Exception) { emptyList() }
        }
        private fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_habit)
            val habits = selected(context)
            val prefs = context.getSharedPreferences("habit_widget", 0)
            val idx = if (habits.isEmpty()) 0 else prefs.getInt("index", 0).coerceIn(0, habits.lastIndex)
            views.setTextViewText(R.id.habit_title, habits.getOrNull(idx)?.second ?: "اختر عادة من قسم العادات")
            views.setTextViewText(R.id.habit_count, if (habits.isEmpty()) "—" else "${idx + 1}/${habits.size}")
            fun pending(action: String, request: Int): PendingIntent {
                val intent = Intent(context, HabitWidget::class.java).setAction(action)
                return PendingIntent.getBroadcast(context, request, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            }
            views.setOnClickPendingIntent(R.id.habit_prev, pending(PREV, 7101))
            views.setOnClickPendingIntent(R.id.habit_next, pending(NEXT, 7102))
            views.setOnClickPendingIntent(R.id.habit_root, PendingIntent.getActivity(context, 7103,
                Intent(context, MainActivity::class.java).putExtra("tab", "habits").addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            manager.updateAppWidget(id, views)
        }
    }
}
